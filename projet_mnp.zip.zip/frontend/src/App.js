import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [projets, setProjets] = useState([]);

  // Utilisation de useEffect pour récupérer les projets depuis l'API Flask
  useEffect(() => {
    axios.get('http://127.0.0.1:5000/projets')
      .then(response => {
        setProjets(response.data);
      })
      .catch(error => console.error("Il y a eu une erreur!", error));
  }, []);

  return (
    <div>
      <h1>Liste des Projets</h1>
      <ul>
        {projets.map(projet => (
          <li key={projet[0]}>
            <strong>{projet[1]}</strong><br />
            Description: {projet[2]}<br />
            Statut: {projet[3]}<br />
            Date début: {projet[4]}<br />
            Date fin: {projet[5]}<br />
            Responsable: {projet[6]}<br />
            Budget: {projet[7]}<br />
            Obstacles: {projet[8]}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
